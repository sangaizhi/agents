---
name: version-committing
description: Quick git commit with auto-generated or specified message
argument-hint: "[optional: commit message]"
disable-model-invocation: true
allowed-tools:
  - Bash(git status:*) 
  - Bash(git add:*)
  - Bash(git commit:*)
  - Bash(git diff:*)
model: deepseek-v4-flash
---

# Task: create a git commit

## Input Handling
If a message is provided: $ARGUMENTS
- Use that as the commit message
If no message is provided:
- Analyze the changes with `git diff --staged` (or `git diff` if nothing staged)
- Generate a concise, meaningful commit message
  
## Current State (Auto-detected)
Git status:
!`git status --short 2>/dev/null || echo "Not a git repository"`

Stage changes:
!`git diff --stageed --stat 2>/dev/null || echo ""Nothing staged`

## Steps
1. Check 'git status' to see current state
2. If nothing staged, run `git add .` to stage all changes
3. Review what will be committed with `git diff --staged` 
4. Create commit with appropriate message
5. Show brief comfirmation
   
## Commit Message Format
- Start with type: `feat:`,`fix:`,`docs:`,`refactor:`,`test:`,`chore:`
- Be consice but descriptive (max 72 chars for first line)
- Example: `feat: add user authentication with JWT`
  
## Output
Show a brief comfirmation:
√ Committed: [commit message]
  [number] files changed
